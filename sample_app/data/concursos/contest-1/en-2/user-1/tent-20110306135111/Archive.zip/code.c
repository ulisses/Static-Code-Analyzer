#include <stdio.h>

int main(int argc,char* argv)
{
//while(1){}
    printf ("%d\n",argc-1);
return argc;
}